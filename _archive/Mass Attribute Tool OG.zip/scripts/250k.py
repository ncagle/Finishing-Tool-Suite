# #############################################################################
# Name: 250kMassAtt_go1.py
# Purpose: Replaces values in required subtype fields for 250k attributes
# Input(s): Feature Dataset - Surfaces, Points, Curves
# Output(s): Feature Dataset - Surfaces, Points, Curves
# Author: Gabby Armour, John Jackson
# Date: 4/6/2021
# #############################################################################

# Note: This program does not work by traditional inheritance. The classes
# obtain their "inherited"  and derived data in the implementation portion
# of the program.

# Note2: This is the cleaned version. There is still major room for
# improvement.

# Note3: Version 1 has a few extra methods to check to see if the
# variables are stored with the right information.

# Note4: Full implementation can be found at the bottom of the program/
# script.

# Note5: This version is based off 50kMassAtt_go1.py.

# Note6: Modded to be gotten out quickly while new variant is being worked on

# Note7: For LEIDOS, Harris, Hexagon

# -- VERSION 1 --

# Import Module(s):

import arcpy as ap

# Input(s)/Outputs(s):

# user input GDB/Dataset with TDS
ap.env.workspace = ap.GetParameterAsText(0) 
workspace = ap.env.workspace

# pulls feature classes from workspace
FC = ap.ListFeatureClasses()

# Class 1 -- Base Class:

class featureClass:

    def __init__(self):

        # feature classes with full path
        self.FC = FC
        
        # feature classes without the full path
        self.FC_names = [] 
        self.exFC_names = []

        # after empty geometry has been removed
        self.exFC_names_ALL = []

        # GDB with TDS from user
        self.workspace = workspace

        # feature exclusion list
        self.exList = ["InformationSrf", "ResourceSrf", "MetadataSrf", # Surfaces
                       "InformationCrv", "AeronauticCrv", # Curves
                       "InformationPnt", "BoundaryPnt", "VegetationPnt"] # Points

    def add_data(self):

        ''' Adds data to the Feature Class class while preserving order. '''
        
        for i in range(len(self.FC)):
            if self.workspace:
                while self.FC[i].startswith(self.workspace + "\\"):
                    self.FC[i] = self.FC[i][len(self.workspace + "\\"):]
                while self.FC[i].endswith(self.workspace + "\\" ):
                    self.FC[i] = self.FC[i][:-len(self.workspace + "\\")]
                self.FC_names.append(self.FC[i])
                
    def excludedFeatureClasses(self):

        ''' This function removes the names of features that will not need to
            be mass attributed. '''

        FC = self.FC_names

        for i in range(len(self.exList)): 
            FC.remove(self.exList[i])

        for i in range(len(self.FC_names)):
                self.exFC_names.append(self.FC_names[i])

    def zeroOutProduction(self):

        ''' This function zeros out the CTUU field in all of the
            input feature classes. Added the startswith modification
            5/1/2020 '''

        for i in range(len(self.exFC_names)):
            with ap.da.UpdateCursor(self.exFC_names[i], ['zi026_ctuu']) as cs:
                for r in cs:
                    if r[0] == None:
                        r[0] = 0
                    elif r[0] in (500000, 250000, 50000):
                        continue
                    else:
                        r[0] = 0
                    cs.updateRow(r)

    def addRequiredField(self):

        ''' This function adds a special field known as Required to the selected
            feature classes. '''

        for i in range(len(self.exFC_names)):
            ap.AddField_management(self.exFC_names[i], "Required", "SHORT")

    def zeroOutRequiredField(self):

        ''' This function zeros out the Required field. '''

        for i in range(len(self.exFC_names)):
            with ap.da.UpdateCursor(self.exFC_names[i],['Required']) as cs:
                for r in cs:
                    r[0] = 0
                    cs.updateRow(r)

    def deleteRequiredField(self):

        ''' This function deletes the Required field. It's to be used
            last. '''

        for i in range(len(self.exFC_names)):
            ap.DeleteField_management(self.exFC_names[i],['Required'])


# Class 2 -- Derived Surfaces:

class surfaceFeatures:

    def __init__(self): 

        # add only surface fcs
        self.sFC = []

        # after empty geometry is taken out
        self.sFC_final = []
        self.exFC_names = []
        self.exFC_names_ALL = []

        # appended curves out of fc
        self.cFC = []

        # appended points out of fc
        self.pFC = [] 
        
    def add_data(self, FC_List):
        self.exFC_names.append(FC_List)
    
    def modify_data(self):

        ''' Crv, Pnt, and Srf are stripped from classes, and Srf is appended
            back into place. '''

        # Curve extension to be stripped
        c = "Crv"

        for i in range(len(self.exFC_names)):
            if c:
                while self.exFC_names[i].startswith(c):
                    self.exFC_names[i] = self.exFC_names[i][len(c):]
                while self.exFC_names[i].endswith(c):
                    self.exFC_names[i] = self.exFC_names[i][:-len(c)]
                self.cFC.append(self.exFC_names[i])
                
        # Point extension to be stripped
        p = "Pnt" 

        for i in range(len(self.cFC)):
            if p:
                while self.cFC[i].startswith(p):
                    self.cFC[i] = self.cFC[i][len(p):]
                while self.cFC[i].endswith(p):
                    self.cFC[i] = self.cFC[i][:-len(p)]
                self.pFC.append(self.cFC[i])
                
        # Surface extension to be stripped
        s = "Srf" 

        for i in range(len(self.pFC)):
            if s:
                while self.pFC[i].startswith(s):
                    self.pFC[i] = self.pFC[i][len(s):]
                while self.pFC[i].endswith(s):
                    self.pFC[i] = self.pFC[i][:-len(s)]
                self.sFC.append(self.pFC[i])

        # Remove identical names
        self.sFC = list(set(self.sFC))

        # Add Srf extension back
        for i in range(len(self.sFC)):
            self.sFC_final.append(self.sFC[i] + "Srf")

            
    def removeEmptyGeometry(self):

        ''' This function removes fields with empty geometry from the list. '''

        exSFC = self.sFC_final
        exSFCALL = self.exFC_names_ALL
        
        for i in range(len(exSFC)):
            k = [r[0] for r in ap.da.SearchCursor(exSFC[i], ["F_CODE"])]
            if k == []:
                exSFCALL.append(exSFC[i])
            elif k != []:
                continue 

        for i in range(len(exSFCALL)):
            exSFC.remove(exSFCALL[i])

# Class 3 -- Derived Curves:

class curveFeatures:

    def __init__(self): 

        # appended surfaces out of fc
        self.sFC = []

        # after empty geometry is taken out
        self.cFC_final = []
        self.exFC_names = []
        self.exFC_names_ALL = [] 
        
        # add only curves fcs
        self.cFC = []

        # appended points out of fc
        self.pFC = [] 
        
    def add_data(self, FC_List): # forced inheritance ???
        self.exFC_names.append(FC_List)
    
    def modify_data(self):

        ''' Crv, Pnt, and Srf are stripped from classes, and Crv is appended
            back into place. '''
        
        # Surface extension to be stripped
        s = "Srf"

        for i in range(len(self.exFC_names)):
            if s:
                while self.exFC_names[i].startswith(s):
                    self.exFC_names[i] = self.exFC_names[i][len(s):]
                while self.exFC_names[i].endswith(s):
                    self.exFC_names[i] = self.exFC_names[i][:-len(s)]
                self.sFC.append(self.exFC_names[i])

        # Point extension to be stripped
        p = "Pnt"

        for i in range(len(self.sFC)):
            if p:
                while self.sFC[i].startswith(p):
                    self.sFC[i] = self.sFC[i][len(p):]
                while self.sFC[i].endswith(p):
                    self.sFC[i] = self.sFC[i][:-len(p)]
                self.pFC.append(self.sFC[i])

        # Curve extension to be stripped
        c = "Crv" 

        for i in range(len(self.pFC)):
            if c:
                while self.pFC[i].startswith(c):
                    self.pFC[i] = self.pFC[i][len(c):]
                while self.pFC[i].endswith(c):
                    self.pFC[i] = self.pFC[i][:-len(c)]
                self.cFC.append(self.pFC[i])

        
        # Remove identical names
        self.cFC = list(set(self.cFC))

        # Add Crv extension back
        for i in range(len(self.cFC)):
            self.cFC_final.append(self.cFC[i] + "Crv")

        # Remove the Crv feature classes that don't exist
        remove = ["FacilityCrv", "AgricultureCrv", "StorageCrv",
                  "SettlementCrv", "HydroAidNavigationCrv"]

        for i in range(len(remove)):
            self.cFC_final.remove(remove[i])
               
    def removeEmptyGeometry(self):

        ''' This function removes fields with empty geometry from the list. '''

        exCFC = self.cFC_final
        exCFCALL = self.exFC_names_ALL
        
        for i in range(len(exCFC)):
            k = [r[0] for r in ap.da.SearchCursor(exCFC[i], ["F_CODE"])] 
            if k == []:
                exCFCALL.append(exCFC[i])
            elif k != []:
                continue

        for i in range(len(exCFCALL)):
            exCFC.remove(exCFCALL[i])

# Class 4 -- Derived Points:

class pointFeatures:

    def __init__(self): 

        # appended surfaces out of fc
        self.sFC = []

        # after empty geometry is taken out
        self.pFC_final = []
        self.exFC_names = []
        self.exFC_names_ALL = []

        # appended curves out of fc
        self.cFC = []

        # add only point fcs
        self.pFC = []
        
    def add_data(self, FC_List):
        self.exFC_names.append(FC_List)
    
    def modify_data(self):

        ''' Crv, Pnt, and Srf are stripped from classes, and Pnt is appended
            back into place. '''
        
        # Surface extension to be stripped
        s = "Srf"

        for i in range(len(self.exFC_names)):
            if s:
                while self.exFC_names[i].startswith(s):
                    self.exFC_names[i] = self.exFC_names[i][len(s):]
                while self.exFC_names[i].endswith(s):
                    self.exFC_names[i] = self.exFC_names[i][:-len(s)]
                self.sFC.append(self.exFC_names[i])

        # Curve extension to be stripped
        c = "Crv"

        for i in range(len(self.sFC)):
            if c:
                while self.sFC[i].startswith(c):
                    self.sFC[i] = self.sFC[i][len(c):]
                while self.sFC[i].endswith(c):
                    self.sFC[i] = self.sFC[i][:-len(c)]
                self.cFC.append(self.sFC[i])

        # Point extension to be stripped
        p = "Pnt"
        
        for i in range(len(self.cFC)):
            if p:
                while self.cFC[i].startswith(p):
                    self.cFC[i] = self.cFC[i][len(p):]
                while self.cFC[i].endswith(p):
                    self.cFC[i] = self.cFC[i][:-len(p)]
                self.pFC.append(self.cFC[i])

        # Remove identical names
        self.pFC = list(set(self.pFC)) 

        # Add Pnt extension back
        for i in range(len(self.pFC)):
            self.pFC_final.append(self.pFC[i] + "Pnt")
            
            
    def removeEmptyGeometry(self):

        ''' This function removes fields with empty geometry from the list. '''

        exPFC = self.pFC_final
        exPFCALL = self.exFC_names_ALL
        
        for i in range(len(exPFC)):
            k = [r[0] for r in ap.da.SearchCursor(exPFC[i], ["F_CODE"])]
            if k == []:
                exPFCALL.append(exPFC[i])
            elif k != []:
                continue

        for i in range(len(exPFCALL)):
            exPFC.remove(exPFCALL[i])

# Interface(s) -- The requirements for mass attribution
# Interface 1 -- Surfaces:

class IRequirementsSurfaces:

    ''' This is a pseudo/future interface to implement the Surface mass
        attribution requirements. Mass attribution function are denoted as
        massAtt#() with a corresponding req_list# outside of the interface. '''

    def __init__(self):

        ''' This data is private to the class; however, it's not properly
        denoted. '''

        self.sFC_list = [] 
        self.req_list = []    

    def add_data1(self, sFC_list):

        ''' Data is pulled from a list during implementation. '''

        self.sFC_list.append(sFC_list)

    def add_data2(self, req_list):
        
        ''' This extra function was made because req_list varies in length from
            the feature class list. Must be in order to work properly. '''
        
        self.req_list.append(req_list)

    def populateRequired(self):

        ''' This will need to be repeated in the other requirement
            interfaces. '''
        
        for i in range(len(self.sFC_list)): 
            with ap.da.UpdateCursor(self.sFC_list[i], ['F_CODE','Required']) as cs:
                for r in cs:
                    r[1] = 0
                    for i in range(len(self.req_list)):
                        if (r[0] == self.req_list[i]):
                            r[1] = 1
                            continue
                    cs.updateRow(r)

    def massAtt1(self): 

        for i in range(len(self.sFC_list)):
            with ap.da.UpdateCursor(self.sFC_list[i], ['Required','zi026_ctuu','ARA']) as cs:
                for r in cs:
                    if r[1] in (500000, 250000, 50000): 
                        continue
                    elif (r[0] == 1) and (r[2] >= 390625): 
                        r[1] = 250000
                    cs.updateRow(r)

    def massAtt2(self): 

        for i in range(len(self.sFC_list)):
            with ap.da.UpdateCursor(self.sFC_list[i], ['Required','zi026_ctuu','ARA']) as cs:
                for r in cs:
                    if r[1] in (500000, 250000, 50000): 
                        continue
                    elif (r[0] == 1) and (r[2] >= 15625): 
                        r[1] = 250000
                    cs.updateRow(r)

    def massAtt3(self): 

        for i in range(len(self.sFC_list)):
            with ap.da.UpdateCursor(self.sFC_list[i], ['Required','zi026_ctuu','HGT']) as cs:
                for r in cs:
                    if r[1] in (500000, 250000, 50000): 
                        continue
                    elif (r[0] == 1) and (r[2] >= 46): 
                        r[1] = 250000
                    cs.updateRow(r)

    def massAtt4(self): 

        for i in range(len(self.sFC_list)):
            with ap.da.UpdateCursor(self.sFC_list[i], ['Required','zi026_ctuu','WID']) as cs:
                for r in cs:
                    if r[1] in (500000, 250000, 50000): 
                        continue
                    elif (r[0] == 1) and (r[2] >= 25): 
                        r[1] = 250000
                    cs.updateRow(r)

    def massAtt5(self): 

        for i in range(len(self.sFC_list)):
            with ap.da.UpdateCursor(self.sFC_list[i], ['Required','zi026_ctuu','LZN']) as cs:
                for r in cs:
                    if r[1] in (500000, 250000, 50000): 
                        continue
                    elif (r[0] == 1) and (r[2] >= 25): 
                        r[1] = 250000
                    cs.updateRow(r)

    def massAtt6(self): 

        for i in range(len(self.sFC_list)):
            with ap.da.UpdateCursor(self.sFC_list[i], ['Required','zi026_ctuu']) as cs:
                for r in cs:
                    if r[1] in (500000, 250000, 50000): 
                        continue
                    elif (r[0] == 1): 
                        r[1] = 250000
                    cs.updateRow(r)

    def massAtt7(self): 

        for i in range(len(self.sFC_list)):
            with ap.da.UpdateCursor(self.sFC_list[i], ['Required','zi026_ctuu','ARA','LMC']) as cs:
                for r in cs:
                    if r[1] in (500000, 250000, 50000): 
                        continue
                    elif (r[0] == 1) and ((r[2] in range(15625, 390625)) and (r[3] == 1001)): 
                        r[1] = 250000
                    cs.updateRow(r)

    def massAtt8(self): 

        for i in range(len(self.sFC_list)):
            with ap.da.UpdateCursor(self.sFC_list[i], ['Required','zi026_ctuu','LZN','LMC','WID']) as cs:
                for r in cs:
                    if r[1] in (500000, 250000, 50000): 
                        continue
                    elif (r[0] == 1) and (r[2] >= 375): 
                        r[1] = 250000
                    elif (r[0] == 1) and ((r[3] == 1001) and (r[4] >= 25)):
                        r[1] = 250000
                    cs.updateRow(r)

    def massAtt9(self): 

        for i in range(len(self.sFC_list)):
            with ap.da.UpdateCursor(self.sFC_list[i], ['Required','zi026_ctuu','LZN']) as cs:
                for r in cs:
                    if r[1] in (500000, 250000, 50000): 
                        continue
                    elif (r[0] == 1) and (r[2] >= 25): 
                        r[1] = 250000
                    cs.updateRow(r)

    def massAtt10(self): 

        for i in range(len(self.sFC_list)):
            with ap.da.UpdateCursor(self.sFC_list[i], ['Required','zi026_ctuu','LMC']) as cs:
                for r in cs:
                    if r[1] in (500000, 250000, 50000): 
                        continue
                    elif (r[0] == 1) and (r[2] == 1001): 
                        r[1] = 250000
                    cs.updateRow(r)

    def massAtt11(self): 

        for i in range(len(self.sFC_list)):
            with ap.da.UpdateCursor(self.sFC_list[i], ['Required','zi026_ctuu','ARA','LMC']) as cs:
                for r in cs:
                    if r[1] in (500000, 250000, 50000): 
                        continue
                    elif (r[0] == 1) and ((r[2] in range(625, 15625)) and (r[3] == 1001)):
                        r[1] = 250000
                    cs.updateRow(r)

    def massAtt12(self): 

        for i in range(len(self.sFC_list)):
            with ap.da.UpdateCursor(self.sFC_list[i], ['Required','zi026_ctuu','LZN']) as cs:
                for r in cs:
                    if r[1] in (500000, 250000, 50000): 
                        continue
                    elif (r[0] == 1) and (r[2] >= 625):
                        r[1] = 250000
                    cs.updateRow(r)

    def massAtt13(self): 

        for i in range(len(self.sFC_list)):
            with ap.da.UpdateCursor(self.sFC_list[i], ['Required','zi026_ctuu','LMC','WID']) as cs:
                for r in cs:
                    if r[1] in (500000, 250000, 50000): 
                        continue
                    elif (r[0] == 1) and ((r[2] >= 1001) and (r[3] > 25)):
                        r[1] = 250000
                    cs.updateRow(r)

    def massAtt14(self): 

        for i in range(len(self.sFC_list)):
            with ap.da.UpdateCursor(self.sFC_list[i], ['Required','zi026_ctuu','ARA','LMC']) as cs:
                for r in cs:
                    if r[1] in (500000, 250000, 50000): 
                        continue
                    elif (r[0] == 1) and ((r[2] in range(625, 15625)) and (r[3] == 1001)):
                        r[1] = 250000
                    cs.updateRow(r)

    def massAtt15(self): 

        for i in range(len(self.sFC_list)):
            with ap.da.UpdateCursor(self.sFC_list[i], ['Required','zi026_ctuu','LZN','LMC']) as cs:
                for r in cs:
                    if r[1] in (500000, 250000, 50000): 
                        continue
                    elif (r[0] == 1) and ((r[2] in range(125, 625)) and (r[3] == 1001)):
                        r[1] = 250000
                    cs.updateRow(r)


# Interface 1 -- Required List(s):
# Note: order is important -- req_list1s -> massAtt1()

req_list1s = ['AK030','AL012','DA005','AL020','AL030','FA210','AA010','AL010','BH135',
            'AK090','BH051','AM075','AK100','AA052','BH082','BA030','BH090','ED020',
            'SU001','EC020','AK120','BB009','AQ116','AB010','AK200','BH160','BH155',
            'BH150','DB170','AL105','AL208','AL351','AM010','AM071','FA165','BJ110',
            'AD060','AK180','BH015','AB000','EC015','EB010','AL270','ED010','EA040',
            'DA010']

req_list2s = ['AL376','AD010','AL130','AM065','AD030','AT045','AD020','AK160']

req_list3s = ['AL012','AQ040','AF030','BI020','AB000','AH055','AM030','BC050',
            'AM070','BI050','AL013']

req_list4s = ['AQ063','BI044','BH020','AL140','BH120','BH010','DB090']

req_list5s = ['AL142','AQ080','AN076','AJ050','AQ125','AL375']

req_list6s = ['GB005','BH020','AT045','AN060','AN076','BH140','AN075','BI030','BA040',
            'GB065']

req_list7s = ['AK030','AL012','AL020','AL030','AA010','AL010','AK090','BH051','AM075',
            'AK100','AA052','BA030','SU001','AK120','BB009','AQ116','AB010','AK200',
            'BH155','BH150','AL105','AL351','AM010','AM071','FA165','AK180']

req_list8s = ['BH010']

req_list9s = ['AL375','AQ080','AJ050']

req_list10s = ['AM030','BH082','BC050','BH120','AD020','AM070','BI050','AJ050']

req_list11s = ['AL130']

req_list12s = ['AL140']

req_list13s = ['AL140']

req_list14s = ['AK160']

req_list15s = ['AL211']


class IRequirementsCurves:

    ''' This is a pseudo/future interface to implement the Curve mass
        attribution requirements. Mass attribution function are denoted as
        massAtt#() with a corresponding req_list# outside of the interface. '''

    def __init__(self):

        ''' This data is private to the class; however, it's not properly
        denoted. '''

        self.cFC_list = [] 
        self.req_list = []    

    def add_data1(self, cFC_list):

        ''' Data is pulled from a list during implementation. '''

        self.cFC_list.append(cFC_list)

    def add_data2(self, req_list):
        
        ''' This extra function was made because req_list varies in length from
            the feature class list. Must be in order to work properly. '''
        
        self.req_list.append(req_list)

    def populateRequired(self):

        ''' This will need to be repeated in the other requirement
            interfaces. '''
        
        for i in range(len(self.cFC_list)): 
            with ap.da.UpdateCursor(self.cFC_list[i], ['F_CODE','Required']) as cs:
                for r in cs:
                    r[1] = 0
                    for i in range(len(self.req_list)):
                        if (r[0] == self.req_list[i]):
                            r[1] = 1
                            continue
                    cs.updateRow(r)

    def massAtt1(self): 

        for i in range(len(self.cFC_list)):
            with ap.da.UpdateCursor(self.cFC_list[i], ['Required','zi026_ctuu','HGT']) as cs:
                for r in cs:
                    if r[1] in (500000, 250000, 50000): 
                        continue
                    elif (r[0] == 1) and (r[2] >= 46): 
                        r[1] = 250000
                    cs.updateRow(r)

    def massAtt2(self): 

        for i in range(len(self.cFC_list)):
            with ap.da.UpdateCursor(self.cFC_list[i], ['Required','zi026_ctuu']) as cs:
                for r in cs:
                    if r[1] in (500000, 250000, 50000): 
                        continue
                    elif (r[0] == 1):
                        r[1] = 250000
                    cs.updateRow(r)

    def massAtt3(self): 

        for i in range(len(self.cFC_list)):
            if self.cFC_list[i] == 'HydrographyCrv':
                with ap.da.UpdateCursor(self.cFC_list[i], ['Required','zi026_ctuu','LZN','LMC','WID']) as cs:
                    for r in cs:
                        if r[1] in (500000, 250000, 50000): 
                            continue
                        elif (r[0] == 1) and (r[2] >= 375) or ((r[3] == 1001) and (r[4] < 25)):
                            r[1] = 250000
                        cs.updateRow(r)

            else:
                continue                

    def massAtt4(self): 

        for i in range(len(self.cFC_list)):
            if self.cFC_list[i] == 'UtilityInfrastructureCrv':
                with ap.da.UpdateCursor(self.cFC_list[i], ['Required','zi026_ctuu','CAB','LMC','HGT']) as cs:
                    for r in cs:
                        if r[1] in (500000, 250000, 50000): 
                            continue
                        elif (r[0] == 1) and (r[2] == 19 or 8 or 7 or 9 or 3 or 4 or 2) and (r[3] == 1001):
                            r[1] = 250000
                        elif (r[0] == 1) and (r[2] == 6) and (r[4] >= 15):
                            r[1] = 250000
                        elif (r[0] == 1) and (r[2] == 10) and (r[4] >= 46):
                            r[1] = 250000
                        elif (r[0] == 1) and (r[2] == 13 or 12 or 11 or 14 or 15) and (r[3] == 1001):
                            r[1] = 250000
                        cs.updateRow(r)

            else:
                continue


    def massAtt5(self): 

        for i in range(len(self.cFC_list)):
            with ap.da.UpdateCursor(self.cFC_list[i], ['Required','zi026_ctuu','LMC']) as cs:
                for r in cs:
                    if r[1] in (500000, 250000, 50000): 
                        continue
                    elif (r[0] == 1) and (r[2] == 1001):
                        r[1] = 250000
                    cs.updateRow(r)

    def massAtt6(self): 

        for i in range(len(self.cFC_list)):
            with ap.da.UpdateCursor(self.cFC_list[i], ['Required','zi026_ctuu','LZN']) as cs:
                for r in cs:
                    if r[1] in (500000, 250000, 50000): 
                        continue
                    elif (r[0] == 1) and (r[2] >= 1500):
                        r[1] = 250000
                    cs.updateRow(r)

    def massAtt7(self): 

        for i in range(len(self.cFC_list)):
            with ap.da.UpdateCursor(self.cFC_list[i], ['Required','zi026_ctuu','LZN']) as cs:
                for r in cs:
                    if r[1] in (500000, 250000, 50000): 
                        continue
                    elif (r[0] == 1) and (r[2] >= 625):
                        r[1] = 250000
                    cs.updateRow(r)

    def massAtt8(self): 

        for i in range(len(self.cFC_list)):
            if self.cFC_list[i] == 'PortHarbourCrv':
                with ap.da.UpdateCursor(self.cFC_list[i], ['Required','zi026_ctuu','LZN','WID']) as cs:
                    for r in cs:
                        if r[1] in (500000, 250000, 50000): 
                            continue
                        elif (r[0] == 1) and ((r[2] >= 625) and (r[3] < 25)):
                            r[1] = 250000
                        cs.updateRow(r)

            else:
                continue

    def massAtt9(self): 

        for i in range(len(self.cFC_list)):
            with ap.da.UpdateCursor(self.cFC_list[i], ['Required','zi026_ctuu','LZN','LMC']) as cs:
                for r in cs:
                    if r[1] in (500000, 250000, 50000): 
                        continue
                    elif (r[0] == 1) and ((r[2] >= 625) and (r[3] == 1001)):
                        r[1] = 250000
                    cs.updateRow(r)

    def massAtt10(self): 

        for i in range(len(self.cFC_list)):
            if self.cFC_list[i] == 'StructureCrv':
                with ap.da.UpdateCursor(self.cFC_list[i], ['Required','zi026_ctuu','LMC','WID']) as cs:
                    for r in cs:
                        if r[1] in (500000, 250000, 50000): 
                            continue
                        elif (r[0] == 1) and ((r[2] == 1000) and (r[3] > 25)):
                            r[1] = 250000
                        cs.updateRow(r)

            else:
                continue

    def massAtt11(self): 

        for i in range(len(self.cFC_list)):
            with ap.da.UpdateCursor(self.cFC_list[i], ['Required','zi026_ctuu','LZN']) as cs:
                for r in cs:
                    if r[1] in (500000, 250000, 50000): 
                        continue
                    elif (r[0] == 1) and (r[2] >= 6250):
                        r[1] = 250000
                    cs.updateRow(r)

    def massAtt12(self): 

        for i in range(len(self.cFC_list)):
            with ap.da.UpdateCursor(self.cFC_list[i], ['Required','zi026_ctuu','LZN']) as cs:
                for r in cs:
                    if r[1] in (500000, 250000, 50000): 
                        continue
                    elif (r[0] == 1) and (r[2] >= 625):
                        r[1] = 250000
                    cs.updateRow(r)

    def massAtt13(self): 

        for i in range(len(self.cFC_list)):
            with ap.da.UpdateCursor(self.cFC_list[i], ['Required','zi026_ctuu','LZN']) as cs:
                for r in cs:
                    if r[1] in (500000, 250000, 50000): 
                        continue
                    elif (r[0] == 1) and (r[2] >= 3000):
                        r[1] = 250000
                    cs.updateRow(r)

    def massAtt14(self): 

        for i in range(len(self.cFC_list)):
            with ap.da.UpdateCursor(self.cFC_list[i], ['Required','zi026_ctuu','LZN']) as cs:
                for r in cs:
                    if r[1] in (500000, 250000, 50000): 
                        continue
                    elif (r[0] == 1) and (r[2] >= 5000):
                        r[1] = 250000
                    cs.updateRow(r)

    def massAtt15(self): 

        for i in range(len(self.cFC_list)):
            if self.cFC_list[i] == 'TransportationGroundCrv':
                with ap.da.UpdateCursor(self.cFC_list[i], ['Required','zi026_ctuu','WID']) as cs:
                    for r in cs:
                        if r[1] in (500000, 250000, 50000): 
                            continue
                        elif (r[0] == 1) and (r[2] < 25):
                            r[1] = 250000
                        cs.updateRow(r)

            else:
                continue    

    def massAtt16(self): 

        for i in range(len(self.cFC_list)):
            if self.cFC_list[i] == 'IndustryCrv':
                with ap.da.UpdateCursor(self.cFC_list[i], ['Required','zi026_ctuu','LZN']) as cs:
                    for r in cs:
                        if r[1] in (500000, 250000, 50000): 
                            continue
                        elif (r[0] == 1) and (r[2] > 325):
                            r[1] = 250000
                        cs.updateRow(r)

            else:
                continue        
                    

# Interface 2 -- Required List(s):
# Note: order is important -- req_list1c -> massAtt1()

req_list1c = ['AQ040','AT041','AF020']

req_list2c = ['AQ070','BA010','BH020','AN010','BI006','BH180','AN050','AQ130']

req_list3c = ['BH010']

req_list4c = ['AT005']

req_list5c = ['AT005','AT041','AK130','BH120']

req_list6c = ['AT041']

req_list7c = ['AL140']

req_list8c = ['BB081']

req_list9c = ['AL260']

req_list10c = ['AL140']

req_list11c = ['AQ113']

req_list12c = ['AK130']

req_list13c = ['BH140']

req_list14c = ['AP030']

req_list15c = ['AQ063']

req_list16c = ['AF020']


# Interface 3 -- Points:

class IRequirementsPoints:

    ''' This is a pseudo/future interface to implement the Point mass
        attribution requirements. Mass attribution function are denoted as
        massAtt#() with a corresponding req_list# outside of the interface. '''

    def __init__(self):

        ''' This data is private to the class; however, it's not properly
        denoted. '''

        self.pFC_list = [] 
        self.req_list = []    

    def add_data1(self, pFC_list):

        ''' Data is pulled from a list during implementation. '''

        self.pFC_list.append(pFC_list)

    def add_data2(self, req_list):
        
        ''' This extra function was made because req_list varies in length from
            the feature class list. Must be in order to work properly. '''
        
        self.req_list.append(req_list)

    def populateRequired(self):

        ''' This will need to be repeated in the other requirement
            interfaces. '''
        
        for i in range(len(self.pFC_list)): 
            with ap.da.UpdateCursor(self.pFC_list[i], ['F_CODE','Required']) as cs:
                for r in cs:
                    r[1] = 0
                    for i in range(len(self.req_list)):
                        if (r[0] == self.req_list[i]):
                            r[1] = 1
                            continue
                    cs.updateRow(r)

    def massAtt1(self): 

        for i in range(len(self.pFC_list)):
            with ap.da.UpdateCursor(self.pFC_list[i], ['Required','zi026_ctuu', 'HGT']) as cs:
                for r in cs:
                    if r[1] in (500000, 250000, 50000): 
                        continue
                    elif (r[0] == 1) and (r[2] >= 46): 
                        r[1] = 250000
                    cs.updateRow(r)

    def massAtt2(self): 

        for i in range(len(self.pFC_list)):
            with ap.da.UpdateCursor(self.pFC_list[i], ['Required','zi026_ctuu']) as cs:
                for r in cs:
                    if r[1] in (500000, 250000, 50000): 
                        continue
                    elif (r[0] == 1):
                        r[1] = 250000
                    cs.updateRow(r)

    def massAtt3(self): 

        for i in range(len(self.pFC_list)):
            with ap.da.UpdateCursor(self.pFC_list[i], ['Required','zi026_ctuu','LZN','LMC']) as cs:
                for r in cs:
                    if r[1] in (500000, 250000, 50000): 
                        continue
                    elif (r[0] == 1) and (r[2] >= 3):
                        r[1] = 250000
                    elif (r[0] == 1) and ((r[3] == 1001) and (r[2] < 25)):
                        r[1] = 250000
                    cs.updateRow(r)

    def massAtt4(self): 

        for i in range(len(self.pFC_list)):
            with ap.da.UpdateCursor(self.pFC_list[i], ['Required','zi026_ctuu','LMC']) as cs:
                for r in cs:
                    if r[1] in (500000, 250000, 50000): 
                        continue
                    elif (r[0] == 1) and (r[2] == 1001):
                        r[1] = 250000
                    cs.updateRow(r)

    def massAtt5(self): 

        for i in range(len(self.pFC_list)):
            if self.pFC_list[i] == 'IndustryPnt':
                with ap.da.UpdateCursor(self.pFC_list[i], ['Required','zi026_ctuu','SRL']) as cs:
                    for r in cs:
                        if r[1] in (500000, 250000, 50000): 
                            continue
                        elif (r[0] == 1) and (r[2] == 1):
                            r[1] = 250000
                        cs.updateRow(r)

            else:
                continue

    def massAtt6(self): 

        for i in range(len(self.pFC_list)):
            with ap.da.UpdateCursor(self.pFC_list[i], ['Required','zi026_ctuu','ARA']) as cs:
                for r in cs:
                    if r[1] in (500000, 250000, 50000): 
                        continue
                    elif (r[0] == 1) and (r[2] < 15625):
                        r[1] = 250000
                    cs.updateRow(r)


# Interface 3 -- Required List(s):
# Note: order is important -- req_list1p -> massAtt1()

req_list1p = ['AL142','AF030','AF040','AF070','AM030','BC050','AT042','AA040',
            'AN076','AM070','AF010','AL241','BI050','AM080','AJ050','AL375',
            'AQ080']

req_list2p = ['GB040','DB150','BD115','AT045','AN075','AP030','BI006','AJ051',
            'AH070','GB030','BH145']

req_list3p = ['AL142','AL375','AQ080','AN076']

req_list4p = ['AL142','AF040','AF070','AM030','BC050','AA040','AN076','AF010','AL241',
            'DB180','BI050','AM080','AJ050','AL375','AQ080','AA054','AM070','AL241',
            'AQ125']

req_list5p = ['AA040']

req_list6p = ['AL376','AD010','AM065','AD030','AT045']


# Full Implementation:

def main():

    # Class 1 -- All Feature Classes:
    FC = featureClass()

    # Class 1 -- Implementation:
    FC.add_data()
    FC.excludedFeatureClasses()
    FC.zeroOutProduction()
    FC.addRequiredField()
    FC.zeroOutRequiredField()

    # Class 2 -- Surfaces:
    sFC = surfaceFeatures()

    # Class 2 -- Implementation:
    for i in range(len(FC.exFC_names)):
        sFC.add_data(FC.exFC_names[i])

    sFC.modify_data()
    sFC.removeEmptyGeometry()

    # Class 3 -- Curves:
    cFC = curveFeatures()

    # Class 3 -- Implementation:
    for i in range(len(FC.exFC_names)):
        cFC.add_data(FC.exFC_names[i])

    cFC.modify_data()
    cFC.removeEmptyGeometry()

    # Class 4 -- Points:
    pFC = pointFeatures()
    
    # Class 4 -- Implementation:
    for i in range(len(FC.exFC_names)):
        pFC.add_data(FC.exFC_names[i])

    pFC.modify_data()
    pFC.removeEmptyGeometry()

    # Interface 1 -- Surface Requirements:
    IRS = IRequirementsSurfaces()

    # Interface 1 -- Implementation:

    # req_list 1
    for i in range(len(sFC.sFC_final)):
        IRS.add_data1(sFC.sFC_final[i])

    for i in range(len(req_list1s)):
        IRS.add_data2(req_list1s[i])

    IRS.populateRequired()
    IRS.massAtt1()
    FC.zeroOutRequiredField()

    # req_list 2
    for i in range(len(sFC.sFC_final)):
        IRS.add_data1(sFC.sFC_final[i])

    for i in range(len(req_list2s)):
        IRS.add_data2(req_list2s[i])

    IRS.populateRequired()
    IRS.massAtt2()
    FC.zeroOutRequiredField()

    # req_list 3
    for i in range(len(sFC.sFC_final)):
        IRS.add_data1(sFC.sFC_final[i])

    for i in range(len(req_list3s)):
        IRS.add_data2(req_list3s[i])

    IRS.populateRequired()
    IRS.massAtt3()
    FC.zeroOutRequiredField()

    # req_list 4
    for i in range(len(sFC.sFC_final)):
        IRS.add_data1(sFC.sFC_final[i])

    for i in range(len(req_list4s)):
        IRS.add_data2(req_list4s[i])

    IRS.populateRequired()
    IRS.massAtt4()
    FC.zeroOutRequiredField()

    # req_list 5
    for i in range(len(sFC.sFC_final)):
        IRS.add_data1(sFC.sFC_final[i])

    for i in range(len(req_list5s)):
        IRS.add_data2(req_list5s[i])

    IRS.populateRequired()
    IRS.massAtt5()
    FC.zeroOutRequiredField()

    # req_list 6
    for i in range(len(sFC.sFC_final)):
        IRS.add_data1(sFC.sFC_final[i])

    for i in range(len(req_list6s)):
        IRS.add_data2(req_list6s[i])

    IRS.populateRequired()
    IRS.massAtt6()
    FC.zeroOutRequiredField()

    # req_list 7
    for i in range(len(sFC.sFC_final)):
        IRS.add_data1(sFC.sFC_final[i])

    for i in range(len(req_list7s)):
        IRS.add_data2(req_list7s[i])

    IRS.populateRequired()
    IRS.massAtt7()
    FC.zeroOutRequiredField()

    # req_list 8
    for i in range(len(sFC.sFC_final)):
        IRS.add_data1(sFC.sFC_final[i])

    for i in range(len(req_list8s)):
        IRS.add_data2(req_list8s[i])

    IRS.populateRequired()
    IRS.massAtt8()
    FC.zeroOutRequiredField()

    # req_list 9
    for i in range(len(sFC.sFC_final)):
        IRS.add_data1(sFC.sFC_final[i])

    for i in range(len(req_list9s)):
        IRS.add_data2(req_list9s[i])

    IRS.populateRequired()
    IRS.massAtt9()
    FC.zeroOutRequiredField()

    # req_list 10
    for i in range(len(sFC.sFC_final)):
        IRS.add_data1(sFC.sFC_final[i])

    for i in range(len(req_list10s)):
        IRS.add_data2(req_list10s[i])

    IRS.populateRequired()
    IRS.massAtt10()
    FC.zeroOutRequiredField()

    # req_list 11
    for i in range(len(sFC.sFC_final)):
        IRS.add_data1(sFC.sFC_final[i])

    for i in range(len(req_list11s)):
        IRS.add_data2(req_list11s[i])

    IRS.populateRequired()
    IRS.massAtt11()
    FC.zeroOutRequiredField()

    # req_list 12
    for i in range(len(sFC.sFC_final)):
        IRS.add_data1(sFC.sFC_final[i])

    for i in range(len(req_list12s)):
        IRS.add_data2(req_list12s[i])

    IRS.populateRequired()
    IRS.massAtt12()
    FC.zeroOutRequiredField()

    # req_list 13
    for i in range(len(sFC.sFC_final)):
        IRS.add_data1(sFC.sFC_final[i])

    for i in range(len(req_list13s)):
        IRS.add_data2(req_list13s[i])

    IRS.populateRequired()
    IRS.massAtt13()
    FC.zeroOutRequiredField()

    # req_list 14
    for i in range(len(sFC.sFC_final)):
        IRS.add_data1(sFC.sFC_final[i])

    for i in range(len(req_list14s)):
        IRS.add_data2(req_list14s[i])

    IRS.populateRequired()
    IRS.massAtt14()
    FC.zeroOutRequiredField()

    # req_list 15
    for i in range(len(sFC.sFC_final)):
        IRS.add_data1(sFC.sFC_final[i])

    for i in range(len(req_list15s)):
        IRS.add_data2(req_list15s[i])

    IRS.populateRequired()
    IRS.massAtt15()
    FC.zeroOutRequiredField()

    # Interface 2 -- Curve Requirements:
    IRC = IRequirementsCurves()

    # Interface 2 -- Implementation:

    # req_list 1
    for i in range(len(cFC.cFC_final)):
        IRC.add_data1(cFC.cFC_final[i])

    for i in range(len(req_list1c)):
        IRC.add_data2(req_list1c[i])

    IRC.populateRequired()
    IRC.massAtt1()
    FC.zeroOutRequiredField()

    # req_list 2
    for i in range(len(cFC.cFC_final)):
        IRC.add_data1(cFC.cFC_final[i])

    for i in range(len(req_list2c)):
        IRC.add_data2(req_list2c[i])

    IRC.populateRequired()
    IRC.massAtt2()
    FC.zeroOutRequiredField()

    # req_list 3
    for i in range(len(cFC.cFC_final)):
        IRC.add_data1(cFC.cFC_final[i])

    for i in range(len(req_list3c)):
        IRC.add_data2(req_list3c[i])

    IRC.populateRequired()
    IRC.massAtt3()
    FC.zeroOutRequiredField()

    # req_list 4
    for i in range(len(cFC.cFC_final)):
        IRC.add_data1(cFC.cFC_final[i])

    for i in range(len(req_list4c)):
        IRC.add_data2(req_list4c[i])

    IRC.populateRequired()
    IRC.massAtt4()
    FC.zeroOutRequiredField()

    # req_list 5
    for i in range(len(cFC.cFC_final)):
        IRC.add_data1(cFC.cFC_final[i])

    for i in range(len(req_list5c)):
        IRC.add_data2(req_list5c[i])

    IRC.populateRequired()
    IRC.massAtt5()
    FC.zeroOutRequiredField()

    # req_list 6
    for i in range(len(cFC.cFC_final)):
        IRC.add_data1(cFC.cFC_final[i])

    for i in range(len(req_list6c)):
        IRC.add_data2(req_list6c[i])

    IRC.populateRequired()
    IRC.massAtt6()
    FC.zeroOutRequiredField()

    # req_list 7
    for i in range(len(cFC.cFC_final)):
        IRC.add_data1(cFC.cFC_final[i])

    for i in range(len(req_list7c)):
        IRC.add_data2(req_list7c[i])

    IRC.populateRequired()
    IRC.massAtt7()
    FC.zeroOutRequiredField()

    # req_list 8
    for i in range(len(cFC.cFC_final)):
        IRC.add_data1(cFC.cFC_final[i])

    for i in range(len(req_list8c)):
        IRC.add_data2(req_list8c[i])

    IRC.populateRequired()
    IRC.massAtt8()
    FC.zeroOutRequiredField()

    # req_list 9
    for i in range(len(cFC.cFC_final)):
        IRC.add_data1(cFC.cFC_final[i])

    for i in range(len(req_list9c)):
        IRC.add_data2(req_list9c[i])

    IRC.populateRequired()
    IRC.massAtt9()
    FC.zeroOutRequiredField()

    # req_list 10
    for i in range(len(cFC.cFC_final)):
        IRC.add_data1(cFC.cFC_final[i])

    for i in range(len(req_list10c)):
        IRC.add_data2(req_list10c[i])

    IRC.populateRequired()
    IRC.massAtt10()
    FC.zeroOutRequiredField()

    # req_list 11
    for i in range(len(cFC.cFC_final)):
        IRC.add_data1(cFC.cFC_final[i])

    for i in range(len(req_list11c)):
        IRC.add_data2(req_list11c[i])

    IRC.populateRequired()
    IRC.massAtt11()
    FC.zeroOutRequiredField()

    # req_list 12
    for i in range(len(cFC.cFC_final)):
        IRC.add_data1(cFC.cFC_final[i])

    for i in range(len(req_list12c)):
        IRC.add_data2(req_list12c[i])

    IRC.populateRequired()
    IRC.massAtt12()
    FC.zeroOutRequiredField()

    # req_list 13
    for i in range(len(cFC.cFC_final)):
        IRC.add_data1(cFC.cFC_final[i])

    for i in range(len(req_list13c)):
        IRC.add_data2(req_list13c[i])

    IRC.populateRequired()
    IRC.massAtt13()
    FC.zeroOutRequiredField()

    # req_list 14
    for i in range(len(cFC.cFC_final)):
        IRC.add_data1(cFC.cFC_final[i])

    for i in range(len(req_list14c)):
        IRC.add_data2(req_list14c[i])

    IRC.populateRequired()
    IRC.massAtt14()
    FC.zeroOutRequiredField()

    # req_list 15
    for i in range(len(cFC.cFC_final)):
        IRC.add_data1(cFC.cFC_final[i])

    for i in range(len(req_list15c)):
        IRC.add_data2(req_list15c[i])

    IRC.populateRequired()
    IRC.massAtt15()
    FC.zeroOutRequiredField()

    # req_list 16
    for i in range(len(cFC.cFC_final)):
        IRC.add_data1(cFC.cFC_final[i])

    for i in range(len(req_list16c)):
        IRC.add_data2(req_list16c[i])

    IRC.populateRequired()
    IRC.massAtt16()
    FC.zeroOutRequiredField()

    # Interface 3 -- Point Requirements:
    IRP = IRequirementsPoints()

    # Interface 3 -- Implementation:

    # req_list 1
    for i in range(len(pFC.pFC_final)):
        IRP.add_data1(pFC.pFC_final[i])

    for i in range(len(req_list1p)):
        IRP.add_data2(req_list1p[i])

    IRP.populateRequired()
    IRP.massAtt1()
    FC.zeroOutRequiredField()

    # req_list 2
    for i in range(len(pFC.pFC_final)):
        IRP.add_data1(pFC.pFC_final[i])

    for i in range(len(req_list2p)):
        IRP.add_data2(req_list2p[i])

    IRP.populateRequired()
    IRP.massAtt2()
    FC.zeroOutRequiredField()

    # req_list 3
    for i in range(len(pFC.pFC_final)):
        IRP.add_data1(pFC.pFC_final[i])

    for i in range(len(req_list3p)):
        IRP.add_data2(req_list3p[i])

    IRP.populateRequired()
    IRP.massAtt3()
    FC.zeroOutRequiredField()

    # req_list 4
    for i in range(len(pFC.pFC_final)):
        IRP.add_data1(pFC.pFC_final[i])

    for i in range(len(req_list4p)):
        IRP.add_data2(req_list4p[i])

    IRP.populateRequired()
    IRP.massAtt4()
    FC.zeroOutRequiredField()

    # req_list 5
    for i in range(len(pFC.pFC_final)):
        IRP.add_data1(pFC.pFC_final[i])

    for i in range(len(req_list5p)):
        IRP.add_data2(req_list5p[i])

    IRP.populateRequired()
    IRP.massAtt5()
    FC.zeroOutRequiredField()

    # req_list 6
    for i in range(len(pFC.pFC_final)):
        IRP.add_data1(pFC.pFC_final[i])

    for i in range(len(req_list6p)):
        IRP.add_data2(req_list6p[i])

    IRP.populateRequired()
    IRP.massAtt6()
    FC.zeroOutRequiredField()

    # Delete 'Required' Field in all FCs

    FC.deleteRequiredField()
        
if __name__ == "__main__": main()

