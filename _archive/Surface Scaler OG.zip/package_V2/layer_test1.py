#Testing creating layers for each subtype in a given feature class

import arcpy as ap


ap.env.workspace = ap.GetParameterAsText(0)

workspace = ap.env.workspace

ap.MakeFeatureLayer_management(workspace, "test_lyr")

count = 0

subCnt = 0

subList = []

with ap.da.SearchCursor("test_lyr", ["fcsubtype", "zi026_ctuu"]) as testCursor:
    for r in testCursor:
        if r[0] not in subList:
            subList.append(r[0])
            subCnt += 1
            ap.AddMessage(str(r[0])+" is in this layer!\n")
        count += 1


ap.AddMessage(str(count)+" Features in FC\n")
ap.AddMessage(str(subCnt)+" Subtypes in FC\n")
ap.AddMessage("Subtypes found: \n")
ap.AddMessage(subList)

lyrList = []

for i in subList:
    lyrName = str(i) + "_lyr"
    lyrList.append(lyrName)
    query = "fcsubtype = "+str(i)
    ap.MakeFeatureLayer_management(workspace, lyrName, query)
    ap.AddMessage(lyrName+" layer created.")

ap.AddMessage(lyrList)

ap.AddMessage("\n\n\n")
subCnt2 = 0
subList2 = []
subFeatCnt = 0
for j in lyrList:
    subFeatCnt = 0
    subCnt2 = 0
    subList2 = []
    ap.AddMessage("Layer Contents for : "+str(j)+"\n")
    with ap.da.SearchCursor(str(j), ["fcsubtype", "zi026_ctuu"]) as testCursor2:
        for line in testCursor2:
            if line[0] not in subList2:
                subList2.append(line[0])
                subCnt2 += 1
                ap.AddMessage(str(line[0])+" is in this layer!")
            subFeatCnt += 1
    ap.AddMessage(str(subFeatCnt)+" Features in FC\n")
    ap.AddMessage(str(subCnt2)+" Subtypes in FC\n")
    ap.AddMessage("Subtypes found: ")
    ap.AddMessage(subList2)

