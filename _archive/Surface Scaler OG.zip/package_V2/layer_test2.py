#Testing update cursor on each subtype layer

import arcpy as ap

ap.env.workspace = ap.GetParameterAsText(0)
workspace = ap.env.workspace


subList = []
lyrList = []

ap.MakeFeatureLayer_management(workspace, "test_lyr")

with ap.da.SearchCursor("test_lyr", ["fcsubtype", "zi026_ctuu"]) as testCursor:
    for r in testCursor:
        if r[0] not in subList:
            subList.append(r[0])



for i in subList:
    lyrName = str(i) + "_lyr"
    lyrList.append(lyrName)
    query = "fcsubtype = "+str(i)
    ap.MakeFeatureLayer_management(workspace, lyrName, query)
    ap.AddMessage(lyrName+" layer created.")



for j in lyrList:
    with ap.da.UpdateCursor(str(j), ["fcsubtype", "zi026_ctuu"]) as testCursor2:
        for line in testCursor2:
            line[1] = int(line[0])
            testCursor2.updateRow(line)
