#Testing the dissolve tool on each subtype layer


import arcpy as ap

ap.env.workspace = ap.GetParameterAsText(0)
workspace = ap.env.workspace

mySplit = workspace.split("\\")
mySplit.pop()
mySplit.pop()

join1 = "\\"
pathDB = join1.join(mySplit)


subList = []
lyrList = []
dissList = []

ap.MakeFeatureLayer_management(workspace, "test_lyr")

with ap.da.SearchCursor("test_lyr", ["fcsubtype", "zi026_ctuu"]) as testCursor:
    for r in testCursor:
        if r[0] not in subList:
            subList.append(r[0])



for i in subList:
    lyrName = str(i) + "_lyr"
    lyrList.append(lyrName)
    query = "fcsubtype = "+str(i)
    ap.MakeFeatureLayer_management(workspace, lyrName, query)
    ap.AddMessage(lyrName+" layer created.")



for j in lyrList:
    dissName = "dissolved_"+str(j)
    dissPath = pathDB + "\\" + dissName
    dissList.append(dissPath)
    ap.Dissolve_management(str(j), dissPath, ["fcsubtype"], [["zi026_ctuu", "FIRST"]], "SINGLE_PART")


for k in dissList:
    ap.Delete_management(str(k))
