#Testing the spatial join tool on each subtype layer with dissolves
#Proof of concept for spliting out a Feature Class by subtypes to
#improve performance of geoprocessing tools

import arcpy as ap

#Get the Feature Class input and set it as the workspace enviroment
ap.env.workspace = ap.GetParameterAsText(0)
workspace = ap.env.workspace

#From the input create a pathway to the database for the temporary outputs created by Dissolve and Spatial Join
mySplit = workspace.split("\\")
mySplit.pop()
mySplit.pop()

join1 = "\\"
pathDB = join1.join(mySplit)

#Declare the lists and dictionary needed to track the subtypes in each process
subList = []
lyrList = []
dissList = []
joinList = []
diss_lyrDict = {}



#Create a list of all feature subtypes in the Feature Class input
with ap.da.SearchCursor(workspace, ["fcsubtype", "zi026_ctuu"]) as testCursor:
    for r in testCursor:
        if r[0] not in subList:
            subList.append(r[0])


#From the subtype list, create a feature layer of only one subtype each
for i in subList:
    lyrName = str(i) + "_lyr"
    lyrList.append(lyrName)             #compile a list for the next step of layers
    query = "fcsubtype = "+str(i)
    ap.MakeFeatureLayer_management(workspace, lyrName, query)
    ap.AddMessage(lyrName+" layer created.")


#From the layer list, create a dissolve shape of the subtype
for j in lyrList:
    dissName = "dissolved_"+str(j)
    dissPath = pathDB + "\\" + dissName
    dissList.append(dissPath)            #compile a list of dissolves/locations
    diss_lyrDict[str(j)] = dissPath      #create a dictionary to associate layer with dissolve(makes next step easier)
    ap.Dissolve_management(str(j), dissPath, ["fcsubtype"], [["zi026_ctuu", "FIRST"]], "SINGLE_PART")


#From the dissolve-layer dictionary, create a Spatial Join of the layers to their respective dissolve
for k in diss_lyrDict:
    joinName = "joined_"+str(k)
    joinPath = pathDB + "\\" + joinName
    joinList.append(joinPath)             #compile a list of joins/locations for the clean-up step
    ap.SpatialJoin_analysis(str(k), str(diss_lyrDict[k]), joinPath, "JOIN_ONE_TO_ONE", "KEEP_ALL", "", "INTERSECT")
    ap.AddMessage(joinName+" Spatial Join Created.")

#Clean Up
    #Use Dissolve list to delete the dissolves from the GDB
##for m in dissList:
##    ap.Delete_management(str(m))
##    #Use Join list to delete the joins from the GDB
##for n in joinList:
##    ap.Delete_management(str(n))
