# #############################################################################
# Name: surfaceScalerV2.py
# Purpose: Scales surfaces based on predetermined parameters included in a 
# CSV file.
# Input(s): Feature Dataset -> Surface, CSV file -> 
# TDS_Srf_Scaler_v2_Data_Refined.csv
# Output(s): Feature Dataset - Surface (Scaled)
# Author(s): John Jackson, Gabby Armour
# Date: 3/24/2021
# #############################################################################

# Note: This program does not work by traditional inheritance. The classes
# obtain their "inherited"  and derived data in the implementation portion
# of the program.

# Note2: This is the cleaned version. There is still major room for
# improvement. Extensions to current version will be added to the Version2
# design notes.

# Note3: Refer to V1 notes and to the v2 folder to find more information
# about this version.

# Note4: Full implementation can be found at the bottom of the program/
# script.

# Note5: This script scales a given surface based on if it is present
# in the PSG CSV file.

# -- VERSION 2 --

# Import Module(s):
import arcpy as ap
import pandas as pd
from compiler.ast import flatten
from collections import Counter
import os

# Input(s)/Output(s):
# Single Surface Feature Class from TDS
ap.env.workspace = ap.GetParameterAsText(0)
FC = ap.env.workspace

# Class 1 - PSG to Two Dictionaries Class
class dictionaries:

    def __init__(self):

        # Relative Path Pull Variables
        self.dirname = os.path.dirname(__file__)
        self.filename = os.path.join(self.dirname, 'TDS_Srf_Scaler_v2_Data_Refined.csv')

        # Field Names for Dictionary to Pull from
        self.fields = [['500k Surface Reqs', '250k Surface Reqs', '50k Surface Reqs'], ['Feature Class Names'], ['FC Subtypes']]

        # Read CSV from relative path of CD into Dictionary
        self.csvWithFields1 = {}
        self.csvWithFields1[self.filename] = self.fields

        # Combined Variables (TDS Reqs, Feature Class Names, and FC Subtypes) for Dictionary Load-In
        self.tds_list = 0 # list of requirements, raw
        self.FC = 0 # FC, raw
        self.FCSubtype = 0 # FC Subtype List, raw

        # TDS Requirement Variables
        self.tds_list2 = [] # nested list of 500k, 250k, and 50k requirements

        # Feature Class Names Variables
        self.FC_flat = 0 # sorted(flatten(FC)) # flatten list, sort list alphabetically
        self.counts = 0 # Counter(FC_flat) # use FC_flat to create dictionary of frequency
        self.FCdict_counts = 0 # dict(counts) # used this as a dictionary of counts

        # FC Subtypes Names Variables
        self.FCSubtype_flat = 0 # do not sort, order is important
        self.FCSubtype_strip = [] # stripped list

        # FC Subtype Nested List Creation Variables
        self.FC_set = 0 # set of unique fc values present in CSV
        self.hiddenIndex = [] # hidden index of counts for index j
        self.x = 0 # logic variable
        self.y1 = 0 # logic variable
        self.y2 = 0 # logic variable
        self.nFCSubtypeList = [] # nested fc subtype list, ideal output

        # Dictionary Output Variables
        self.FCsWithSubtypes = {}
        self.subsWithReqs = {}


    def columnsToList(self):

        ''' Changes PSG columns from CSV to list '''

        for i in range(len(self.fields)):
            
            # tds_reqs1 is private to function/class mod
            tds_reqs1 = pd.read_csv(self.filename, usecols=self.csvWithFields1[self.filename][i])

            if i == 0:
                self.tds_list = tds_reqs1.values.tolist()
    
            if i == 1:
                self.FC = tds_reqs1.values.tolist()

            if i == 2:
                self.FCSubtype = tds_reqs1.values.tolist()

        return self.tds_list, self.FC, self.FCSubtype

    def modData(self):

        ''' Modifies TDS Requirements, Feature Classes, and FC Subtypes into a usable form. '''

        # Place TDS Requirements from CSV Column into Nested List
        for i in range(len(self.tds_list)):
    
            self.tds_list2.append([]) # important step to preserve nested lists
    
            for j in range(len(self.tds_list[i])):
                tds_string = str(self.tds_list[i][j]) # strips Long value
                tds_newInt = int(tds_string) # changes back to int without L at end
                self.tds_list2[i].append(tds_newInt)

        # Strip Long (L) Values from FCSubtype_flat
        self.FCSubtype_flat = flatten(self.FCSubtype)      
        
        for subtypes in self.FCSubtype_flat:
            tds_int = int(subtypes)
            self.FCSubtype_strip.append(tds_int)

    def hiddenIndexCreation(self):

        ''' Sets the hidden index to create a multisized nested FC Subtype List. '''

        # Set Feature Class Names Variables
        self.FC_flat = sorted(flatten(self.FC)) # flatten list, sort list alphabetically
        self.counts = Counter(self.FC_flat) # use FC_flat to create dictionary of frequency
        self.FCdict_counts = dict(self.counts) # used this as a dictionary of counts

        # FC Subtype Nested List Creation Variables
        self.FC_set = sorted(list(set(self.FC_flat)))

        # Set-up Hidden Index
        for i in range(len(self.FC_set)): 
            self.hiddenIndex.append(self.FCdict_counts[self.FC_set[i]])

        # Preserved Hidden Indexing
        for i in range(len(self.hiddenIndex)):

            self.nFCSubtypeList.append([])

            if self.y2 == 0:
                self.y1 = self.hiddenIndex[i]
                for j in range(self.x, self.y1):
                    self.nFCSubtypeList[i].append(self.FCSubtype_strip[j])
                self.x = self.y1        

            else:
                self.y1 = self.y1 + self.hiddenIndex[i]
                for j in range(self.x, self.y1):
                    self.nFCSubtypeList[i].append(self.FCSubtype_strip[j])
                self.x = self.y1        

            self.y2 += 1

        # Return to Keep Some Values
        return self.FC_set

    def createDictionary1(self):

        ''' Create 1st Dictionary - Feature Classes with Subtypes '''

        i = 0
        for featureClass in self.FC_set:
            self.FCsWithSubtypes[featureClass] = self.nFCSubtypeList[i]
            i += 1 # same as i++

        return self.FCsWithSubtypes # output

    def createDictionary2(self):

        ''' Create 2nd Dictionary - Subtypes with Requirements '''

        i = 0
        for fcSubtype in self.FCSubtype_strip:
            self.subsWithReqs[fcSubtype] = self.tds_list2[i]
            i += 1 # same as i++

        return self.subsWithReqs # output

# Class 2 - Feature Manipulation
class feature:

    def __init__(self):
       
        # Feature Class with Full Path
        self.FC = FC
        self.pop1 = None

        # Path to GDB/SDE of Feature Class
        self.path2database = None

        # Temporary Outputs - disolve and spatialjoin
        self.dissolved = "\\" + "dissolved"
        self.dissolved1 = None
        self.spatialJoin = "\\" + "spatialjoin"
        self.spatialJoin1 = None

        # Check Geometry Test
        self.emptyGeometryTest = []

        # Variable Set-up for Second Cursor Process
        self.F_CODE = []
        self.OID = []
        self.CTUUS = []

        # Dictionaries from PSG.py
        self.FCsWithSubtypes = 0 
        self.subsWithReqs = 0

    def modData(self): 

        ''' Function that modifies the input for further use. '''
       
        # Split Data 
        mySplit = self.FC.split("\\")

        # Popping Data in List
        mySplit.pop()
        mySplit.pop(-1)

        # Joining after the Pop
        join1 = "\\"
        myJoin = join1.join(mySplit)

        # Add to Internal Object
        self.path2database = myJoin

        # return items
        return self.path2database       

    def popItems(self):

        ''' Function that mods the first popped item. '''

        # Store pop'd items for string manipulation use
        # Split Data
        mySplit = self.FC.split("\\")
        
        # Return the First Pop for Later
        self.pop1 = mySplit.pop()

        # return items
        return self.pop1

    def checkEmptyGeometry(self):

        ''' Function that checks for empty geometry. '''
        
        # Check to see if surface feature is empty
        SF = [str(self.FC)]
        SF1 = self.emptyGeometryTest
        self.emptyGeometryTest = SF1
        
        for i in range(len(SF)):
            k = [r[0] for r in ap.da.SearchCursor(SF[i], ["FCSUBTYPE"])]
            if k == []:
                continue
            elif k != []:
                SF1.append(SF[i]) 

        # Return Empty Geometry for Conditional Use in Dissolve
        return self.emptyGeometryTest

    def dissolveFeatures(self):

        ''' Function that creates the dissolved shapefile. '''
       
        # Get Path to Feature Class
        SF = str(self.FC) 

        # Get Path to Database
        P2D = str(self.path2database)

        # Get Dissolved Feature Table
        dissolved = P2D + str(self.dissolved)
        self.dissolved1 = dissolved

        # Create Dissolved Feature Table
        ap.Dissolve_management(SF, dissolved, ["fcsubtype"], [["zi026_ctuu", "FIRST"]], \
                               "SINGLE_PART", "DISSOLVE_LINES")

        # Return items
        return self.dissolved1

    def cursorProcess1(self, FC_key, FCsWithSubtypes, subsWithReqs): 

        ''' Function that uses the Update Cursor and conditionals to fill in the dissolved
            shapefile. '''
         
        # Settlement Srf Cursor Test
        if len(self.emptyGeometryTest) == 1:

            # Vegetation Srf
            # Note: OID is not being used.
            if str(self.pop1) == str(FC_key):
                ap.AddMessage("It works. {} == {}".format(str(self.pop1), str(FC_key)))
                with ap.da.UpdateCursor(self.dissolved1, ["OID@", "SHAPE@", "FIRST_zi026_ctuu", "FCSUBTYPE"]) as cs:
                    for r in cs:
                        # calculate squaremeters
                        squareMeters = int(round(r[1].getArea('Geodesic', 'SquareMeters')))

                        # "zero" out
                        r[2] = -999999
                        #ap.AddMessage("-----------"+"\n"+
                        #              "Object: "+str(r[0])+"\n"+"FCSubtype: "+str(r[3])
                        #              +"\n"+"----------"+'\n')

                        # checks for reqs
                        if r[3] in FCsWithSubtypes[FC_key]:

                            # req variables
                            Req_500k = subsWithReqs[r[3]][0]
                            Req_250k = subsWithReqs[r[3]][1]
                            Req_50k = subsWithReqs[r[3]][2]
                            #ap.AddMessage("Subtype: "+str(r[3])+"\n"+"500k: "+str(Req_500k)+"\n"+"250k: "+str(Req_250k)+"\n"+"50k: "+str(Req_50k)+"\n")
                            # 50k
                            if Req_50k > 0:
                                if Req_50k == 1:
                                    r[2] = 50000
                                elif squareMeters >= Req_50k: 
                                    r[2] = 50000
                            # 250k
                            if Req_250k > 0:
                                if squareMeters >= Req_250k:
                                    r[2] = 250000
                            # 500k
                            if Req_500k > 0:
                                if squareMeters >= Req_500k:
                                    r[2] = 500000

                        #ap.AddMessage("Value Assigned: "+str(r[2])+"\n\n")
                        cs.updateRow(r)

            else:
                ap.AddMessage("Feature class provided is outside of tool scope.")
            
        else:
            ap.AddMessage("Empty geometry dectected. Tool will not work.")

    def joinDF2FS(self):

        ''' Function that creates a spatial join between the input feature class and the
            dissolve shapefile. '''
       
        # Get Path to Feature Class
        SF = str(self.FC) 

        # Get Path to Database
        P2D = str(self.path2database)

        # Get Dissolved Feature Table
        spatialJoin = P2D + str(self.spatialJoin)
        self.spatialJoin1 = spatialJoin

        # Create Dissolved Feature Table
        ap.SpatialJoin_analysis(SF, self.dissolved1, self.spatialJoin1, "JOIN_ONE_TO_ONE", "KEEP_ALL", "", "WITHIN")

        # Return items
        return self.spatialJoin1

    def cursorProcess2(self):
        
        ''' Function that utilizes both the Search Cursor and the Update Cursor from the 
            Data Access module inside of the ArcPy module to edit the data in the input
            feature class/surface. '''


        # First Cursor to Transfer Field
        with ap.da.SearchCursor(self.spatialJoin1, ["fcsubtype","OID@","FIRST_zi026_ctuu"]) as cs:
            for r in cs:
                self.F_CODE.append(r[0])
                self.OID.append(r[1])
                self.CTUUS.append(r[2])

        # Second Cursor to Complete Transfer and Update Fields in Table
        i = 0 # index start
        with ap.da.UpdateCursor(self.FC, ["ZI026_CTUU"]) as cs:
            for r in cs:
                #Changed this line from V2.0 to make sure the -999999 values are being written to database
                r[0] = self.CTUUS[i]
                
                i += 1
                cs.updateRow(r)

    def delete(self):

        ''' Function that deletes the intermediate shapefiles after usage. '''

        # Get Path to Database
        P2D = str(self.path2database)

        # Get Dissolved & Spatial Join Feature Table
        dissolved = P2D + str(self.dissolved)
        spatialJoin = P2D + str(self.spatialJoin)
    
        # Delete dissolved
        #ap.Delete_management(dissolved)

        # Delete spatialjoin
        #ap.Delete_management(spatialJoin)


# Full Implementation
def main():

    # Class 1 -- Generate Two Dictionaries:
    ds = dictionaries()

    # Class 1 -- Implementation:
    ds.columnsToList()
    ds.modData()
    ds.hiddenIndexCreation()
    ds.createDictionary1()
    ds.createDictionary2()

    # Class 2 -- Surface Feature Class:
    SF = feature()

    # Class 2 -- Implementation:
    SF.modData()
    SF.popItems()
    SF.checkEmptyGeometry() 
    SF.dissolveFeatures() 
    SF.cursorProcess1(FC_key= str(SF.pop1), FCsWithSubtypes= ds.FCsWithSubtypes, subsWithReqs= ds.subsWithReqs) 
    SF.joinDF2FS() 
    SF.cursorProcess2()
    SF.delete()

if __name__ == "__main__": main()
