# #############################################################################
# Name: surfaceScalerV1.py
# Purpose: Scales surfaces based on predetermined parameters.
# Input(s): Feature Dataset - Surface(s)
# Output(s): Feature Dataset - Surface(s)
# Author(s): Gabby Armour, John Jackson
# Date: 12/7/2020
# #############################################################################

# Note: This program does not work by traditional inheritance. The classes
# obtain their "inherited"  and derived data in the implementation portion
# of the program.

# Note2: This is the cleaned version. There is still major room for
# improvement.

# Note3: codeOutline.py has a few extra methods to check to see if the
# variables are stored with the right information.

# Note4: Full implementation can be found at the bottom of the program/
# script.

# Note5: This script only scales the following surfaces: Vegetation Surfaces,
# Physiography Surfaces, and Agriculture Surfaces. DO NOT run the tool
# on any other features unless instructed.

# -- VERSION 1 --

# Import Module(s):
import arcpy as ap

# Input(s)/Output(s):
# Single Surface Feature Class from TDS
ap.env.workspace = ap.GetParameterAsText(0)
FC = ap.env.workspace

# Class 1 - Feature Manipulation
class feature:

    def __init__(self):
       
        # Feature Class with Full Path
        self.FC = FC
        self.pop1 = None

        # Path to GDB/SDE of Feature Class
        self.path2database = None

        # Temporary Outputs - disolve and spatialjoin
        self.dissolved = "\\" + "dissolved"
        self.dissolved1 = None
        self.spatialJoin = "\\" + "spatialjoin"
        self.spatialJoin1 = None

        # Check Geometry Test
        self.emptyGeometryTest = []

        # Variable Set-up for Second Cursor Process
        self.F_CODE = []
        self.OID = []
        self.CTUUS = []

    def modData(self): 

        ''' Function that modifies the input for further use. '''
       
        # Split Data 
        mySplit = self.FC.split("\\")

        # Popping Data in List
        mySplit.pop()
        mySplit.pop(-1)

        # Joining after the Pop
        join1 = "\\"
        myJoin = join1.join(mySplit)

        # Add to Internal Object
        self.path2database = myJoin

        # return items
        return self.path2database       

    def popItems(self):

        ''' Function that mods the first popped item. '''

        # Store pop'd items for string manipulation use
        # Split Data
        mySplit = self.FC.split("\\")
        
        # Return the First Pop for Later
        self.pop1 = mySplit.pop()

        # return items
        return self.pop1

    def checkEmptyGeometry(self):

        ''' Function that checks for empty geometry. '''
        
        # Check to see if surface feature is empty
        SF = [str(self.FC)]
        SF1 = self.emptyGeometryTest
        self.emptyGeometryTest = SF1
        
        for i in range(len(SF)):
            k = [r[0] for r in ap.da.SearchCursor(SF[i], ["F_CODE"])]
            if k == []:
                continue
            elif k != []:
                SF1.append(SF[i]) 

        # Return Empty Geometry for Conditional Use in Dissolve
        return self.emptyGeometryTest

    def dissolveFeatures(self):

        ''' Function that creates the dissolved shapefile. '''
       
        # Get Path to Feature Class
        SF = str(self.FC) 

        # Get Path to Database
        P2D = str(self.path2database)

        # Get Dissolved Feature Table
        dissolved = P2D + str(self.dissolved)
        self.dissolved1 = dissolved

        # Create Dissolved Feature Table
        ap.Dissolve_management(SF, dissolved, ["f_code"], [["zi026_ctuu", "FIRST"]], \
                               "SINGLE_PART", "DISSOLVE_LINES")

        # Return items
        return self.dissolved1

    def cursorProcess1(self): 

        ''' Function that uses the Update Cursor and conditionals to fill in the dissolved
            shapefile. '''
         
        # Settlement Srf Cursor Test
        if len(self.emptyGeometryTest) == 1:

            # Vegetation Srf
            if str(self.pop1) == "VegetationSrf":
                with ap.da.UpdateCursor(self.dissolved1, ["OID@", "SHAPE@", "FIRST_zi026_ctuu", "f_code"]) as cs:
                    for r in cs:
                        # calculate squaremeters
                        squareMeters = int(round(r[1].getArea('Geodesic', 'SquareMeters')))

                        # "zero" out
                        r[2] = -999999
                        
                        # checks
                        if r[3] in ('ED010', 'ED020', 'BJ110'): 
                            # 50k
                            if squareMeters >= 62500: 
                                r[2] = 50000
                            # 250k
                            if squareMeters >= 390625:
                                r[2] = 250000
                            # 500k
                            if squareMeters >= 1562500:
                                r[2] = 500000

                        elif r[3] in ('EC015', 'EB010'): 
                            # 50k
                            if squareMeters >= 62500: 
                                r[2] = 50000
                            # 250k
                            if squareMeters >= 390625:
                                r[2] = 250000

                        elif r[3] in ('EB020'): 
                            # 50k
                            if squareMeters >= 62500: 
                                r[2] = 50000

                        elif r[3] in ('BH015'): 
                            # 50k
                            if squareMeters >= 15625: 
                                r[2] = 50000
                            # 250k
                            if squareMeters >= 390625:
                                r[2] = 250000
                            # 500k
                            if squareMeters >= 1562500:
                                r[2] = 500000

                        cs.updateRow(r)

            # Physiography Srf
            elif str(self.pop1) == "PhysiographySrf":
                with ap.da.UpdateCursor(self.dissolved1, ["OID@", "SHAPE@AREA", "FIRST_zi026_ctuu", "f_code"]) as cs:
                    for r in cs:
                        # calculate squaremeters
                        squareMeters = float(r[1]) * 12321000000

                        # "zero" out
                        r[2] = -999999
                        
                        # checks
                        if r[3] in ('BJ030', 'DB170', 'BJ100'): 
                            # 50k
                            if squareMeters >= 62500: 
                                r[2] = 50000
                            # 250k
                            if squareMeters >= 390625:
                                r[2] = 250000
                            # 500k
                            if squareMeters >= 1562500:
                                r[2] = 500000

                        elif r[3] in ('DA010'): 
                            # 50k
                            if squareMeters >= 62500: 
                                r[2] = 50000
                            # 250k
                            if squareMeters >= 390625:
                                r[2] = 250000

                        elif r[3] in ('BH160', 'BH150'): 
                            # 50k
                            if squareMeters >= 15625: 
                                r[2] = 50000
                            # 250k
                            if squareMeters >= 390625:
                                r[2] = 250000
                            # 500k
                            if squareMeters >= 1562500:
                                r[2] = 500000
                            
                        cs.updateRow(r)
            
            # Agriculture Srf
            elif str(self.pop1) == "AgricultureSrf":
                with ap.da.UpdateCursor(self.dissolved1, ["OID@", "SHAPE@AREA", "FIRST_zi026_ctuu", "f_code"]) as cs:
                    for r in cs:
                        # calculate squaremeters
                        squareMeters = float(r[1]) * 12321000000

                        # "zero" out
                        r[2] = -999999
                        
                        # checks
                        if r[3] in ('BH135'): 
                            # 50k
                            if squareMeters >= 62500: 
                                r[2] = 50000
                            # 250k
                            if squareMeters >= 390625:
                                r[2] = 250000
                            # 500k
                            if squareMeters >= 1562500:
                                r[2] = 500000

                        elif r[3] in ('EA040', 'EA050'): 
                            # 50k
                            if squareMeters >= 62500: 
                                r[2] = 50000
                            # 250k
                            if squareMeters >= 390625:
                                r[2] = 250000

                        elif r[3] in ('EA055'): 
                            # 50k
                            if squareMeters >= 62500: 
                                r[2] = 50000
                            
                        cs.updateRow(r)

            else:
                ap.AddMessage("Feature class provided is outside of tool scope.")
            
        else:
            ap.AddMessage("Empty geometry dectected. Tool will not work.")

    def joinDF2FS(self):

        ''' Function that creates a spatial join between the input feature class and the
            dissolve shapefile. '''
       
        # Get Path to Feature Class
        SF = str(self.FC) 

        # Get Path to Database
        P2D = str(self.path2database)

        # Get Dissolved Feature Table
        spatialJoin = P2D + str(self.spatialJoin)
        self.spatialJoin1 = spatialJoin

        # Create Dissolved Feature Table
        ap.SpatialJoin_analysis(SF, self.dissolved1, self.spatialJoin1, "JOIN_ONE_TO_ONE", "KEEP_ALL", "", "INTERSECT")

        # Return items
        return self.spatialJoin1

    def cursorProcess2(self):
        
        ''' Function that utilizes both the Search Cursor and the Update Cursor from the 
            Data Access module inside of the ArcPy module to edit the data in the input
            feature class/surface. '''


        # First Cursor to Transfer Field
        with ap.da.SearchCursor(self.spatialJoin1, ["f_code","OID@","FIRST_zi026_ctuu"]) as cs:
            for r in cs:
                self.F_CODE.append(r[0])
                self.OID.append(r[1])
                self.CTUUS.append(r[2])

        # Second Cursor to Complete Transfer and Update Fields in Table
        i = 0 # index start
        with ap.da.UpdateCursor(self.FC, ["ZI026_CTUU"]) as cs:
            for r in cs:
                # check
                if self.CTUUS[i] != -999999:
                    r[0] = self.CTUUS[i]
                
                i += 1
                cs.updateRow(r)

    def delete(self):

        ''' Function that deletes the intermediate shapefiles after usage. '''

        # Get Path to Database
        P2D = str(self.path2database)

        # Get Dissolved & Spatial Join Feature Table
        dissolved = P2D + str(self.dissolved)
        spatialJoin = P2D + str(self.spatialJoin)
    
        # Delete dissolved
        ap.Delete_management(dissolved)

        # Delete spatialjoin
        ap.Delete_management(spatialJoin)


# Full Implementation
def main():

    # Class 1 -- Surface Feature Class
    SF = feature()

    # Class 1 -- Implementation:
    SF.modData()
    SF.popItems()
    SF.checkEmptyGeometry() 
    SF.dissolveFeatures() 
    SF.cursorProcess1() 
    SF.joinDF2FS() 
    SF.cursorProcess2()
    SF.delete()

if __name__ == "__main__": main()